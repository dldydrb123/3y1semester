package com.example.numberquiz;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Random;

public class QuizFragment extends Fragment {

    private int randomNumber;
    private TextView questionText;
    private EditText answerInput;
    private Button submitButton;
    private TextView resultText;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_quiz, container, false);

        questionText = view.findViewById(R.id.question_text);
        answerInput = view.findViewById(R.id.answer_input);
        submitButton = view.findViewById(R.id.submit_button);
        resultText = view.findViewById(R.id.result_text);

        randomNumber = new Random().nextInt(10) + 1;

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });

        return view;
    }

    private void checkAnswer() {
        String answer = answerInput.getText().toString();
        if (!answer.isEmpty()) {
            int userGuess = Integer.parseInt(answer);
            if (userGuess == randomNumber) {
                resultText.setText("정답! 숫자는 " + randomNumber);
            } else {
                resultText.setText("땡! 다시 풀어보세요.");
            }
        } else {
            resultText.setText("숫자를 입력해주세요.");
        }
    }
}
